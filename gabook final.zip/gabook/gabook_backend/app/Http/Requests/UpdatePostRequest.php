<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdatePostRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            "text" => "required|string",
            "book_id" => "required|integer|exists:books,id",
            "post_id" => "required|integer|exists:posts,id"
        ];
    }

    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json(
            [
                'success' => false,
                'message' => 'Validation errors',
                'data' => $validator->errors()
            ]
        ));
    }

    public function messages(): array
    {
        return [
            "required" => "O campo :attribute é obrigatório.",
            "string" => "O campo :atribute deve possuir texto",
            "book_id.exists" => "O livro selecionado não existe",
            "post_id.exists" => "O post não existe",
        ];
    }
}
