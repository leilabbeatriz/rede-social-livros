<?php

use App\Http\Controllers\Api\UserController;
use App\Http\Middleware\ApiAuthMiddleware;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->group(function () {
    Route::get("/user", [UserController::class, 'getUser']);
    Route::get("/user/image", [UserController::class, 'getUserImage']);
    Route::post("/user/follow", [UserController::class, 'followUser']);
    Route::get("/user/followingAndFollowers", [UserController::class, 'getFollowingAndFollowers']);
});
