import { Button, Col, Container, Form, FormSelect, Navbar, Row, Spinner } from "react-bootstrap";
import { useParams } from "react-router-dom";
import NavbarTop from "../../components/navbar";
import { useEffect, useState } from "react";

import * as Yup from 'yup';
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import GetUserBooks from "../../api/book/getUserBooks";
import GetPost from "../../api/post/getPost";
import UpdatePost from "../../api/post/UpdatePost";

const validationSchema = Yup.object({
    book: Yup.number().required('Livro obrigatório'),
    text: Yup.string().required('Texto obrigatório'),
})

const PostEdit = () => {
    const { id } = useParams();

    const { register, handleSubmit, formState: { errors } } = useForm({
        resolver: yupResolver(validationSchema) // Resolver de validação com Yup
    });

    const token = localStorage.getItem('token');
    const profilePathImage = localStorage.getItem("userImage");

    const baseUrl = `${process.env.REACT_APP_API_URL}:${process.env.REACT_APP_API_PORT}`;

    const [sendingPost, setSendingPost] = useState(false);
    const [loadingPost, setLoadingPost] = useState(true);
    const [loadingBooks, setLoadingBooks] = useState(true);
    const [books, setBooks] = useState([]);
    const [post, setPost] = useState([]);

    useEffect(() => {
        const getBooks = async () => {
            try {
                const response = await GetUserBooks(token);
                setBooks(response.data.data);
            } catch (error) {
                console.log(error);
            } finally {
                setLoadingBooks(false);
            }
        }

        const getPost = async () => {
            try {
                const response = await GetPost(id);
                setPost(response.data.data);
                setLoadingPost(false);
            } catch (err) {
                alert("Ocorreu um erro ao carregar o post!");
                console.log(err);
            }
        }

        getPost();
        getBooks();
    }, [])

    const sendPost = async (data) => {
        try {
            setSendingPost(true);
            const post = await UpdatePost(id, data.book, data.text);
            setSendingPost(false);
            window.location.href = '/posts';
        } catch (err) {
            alert("Ocorreu um erro ao enviar o post!");
            console.log(err);
        }
    }

    if (loadingPost)
        return (
            <>
                <NavbarTop />
                <div className='d-flex align-items-center justify-content-center my-3'>
                    <Spinner animation="border" role="status" />
                    <p className='m-0 ms-3'>Carregando post...</p>
                </div>
            </>
        )

    return (
        <>
            <NavbarTop />

            <Container>
                <div className='bg-white p-3 rounded-3 mt-5'>
                    <Row className='d-flex justify-items-center'>
                        <Col className=' col-auto'>
                            <img className='rounded-circle' src={profilePathImage ? baseUrl + '/' + profilePathImage : "/icons/user3.png"} width={32} height={32} alt="user icon" />
                        </Col>
                        <Col className='col-auto'>
                            <p className='m-0'>Alterar postagem</p>
                        </Col>
                    </Row>

                    <Form onSubmit={handleSubmit(sendPost)}>
                        {loadingBooks ? (
                            <div className='d-flex align-items-center justify-content-center my-3'>
                                <Spinner animation="border" role="status" />
                                <p className='m-0 ms-3'>Carregando livros...</p>
                            </div>
                        ) : (
                            <>
                                <FormSelect {...register('book')} aria-label="Default select example" className='mt-3'>
                                    {books.map(book => (
                                        <option key={book.id} value={book.book.id}>{book.book.title}</option>
                                    ))}
                                </FormSelect>
                                {errors.book && (
                                    <div className="invalid-feedback d-block">
                                        {errors.book.message}
                                    </div>
                                )}</>
                        )}

                        <Form.Control {...register('text')} defaultValue={post.text} className={`mt-2 ${errors.text ? 'is-invalid' : ''}`} as="textarea" rows={3} />
                        {errors.text && (
                            <div className="invalid-feedback d-block">
                                {errors.text.message}
                            </div>
                        )}

                        <div className='d-flex justify-content-end'>
                            {sendingPost ? (
                                <Button disabled={sendingPost} type='submit' className={"mt-3 rounded-pill btn-gabook disabled"} ><Spinner size='sm' animation="border" role="status" /></Button>
                            ) :
                                <Button disabled={sendingPost} type='submit' className={sendingPost ? "mt-3 rounded-pill btn-gabook disabled" : "mt-3 rounded-pill btn-gabook"} >Salvar</Button>
                            }
                        </div>

                    </Form>

                </div>
            </Container>

        </>
    )

    // return (

    // )
}

export default PostEdit;