// pages/Logout.js

import { useEffect } from 'react';
import { Spinner } from 'react-bootstrap';  // Spinner para mostrar o carregamento
import LogoutApi from '../../api/auth/logout';  // Importando a função de logout

const Logout = () => {
    useEffect(() => {
        const performLogout = async () => {
            try {
                await LogoutApi();  // Chamando a função de logout
                localStorage.removeItem('token');  // Removendo o token do localStorage
                localStorage.removeItem('userImage');  // Removendo a imagem do usuário do localStorage
                window.location.href = '/';  // Redirecionando o usuário para a página inicial
            } catch (error) {
               
            }
        };

        performLogout();  // Executando o logout

    }, []);

    return (
        <div
            className="d-flex justify-content-center align-items-center"
            style={{ height: "100vh" }}
        >
            <Spinner animation="border" variant="info" />
        </div>
    );
};

export default Logout;
