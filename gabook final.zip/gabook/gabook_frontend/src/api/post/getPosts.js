import AxiosBase from "../axiosBase";

const GetPosts = () => {
    const token = localStorage.getItem('token');
    return AxiosBase.get("/post", {}, { Headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }); 
}

export default GetPosts;
