import AxiosBase from "../axiosBase";

const GetPost = (id) => {
    const token = localStorage.getItem('token');
    return AxiosBase.get(`/post/${id}`, {headers: {Authorization: `Bearer ${token}`}}); 
}

export default GetPost;
