import AxiosBase from "../axiosBase";

const UpdatePost = async (id, bookId, description) => {
    const token = localStorage.getItem('token');
    return AxiosBase.put(`/post/${id}`, {post_id: id, book_id: bookId, text: description}, {headers: {Authorization: `Bearer ${token}`}});
}

export default UpdatePost;