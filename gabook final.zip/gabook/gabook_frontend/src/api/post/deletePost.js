import AxiosBase from "../axiosBase";

const DeletePost = (id) => {
    const token = localStorage.getItem('token');
    return AxiosBase.delete(`/post/${id}`, {headers: {Authorization: `Bearer ${token}`}}); 
}

export default DeletePost;
