import AxiosBase from "../axiosBase";

const GetUser = (token) => {
    return AxiosBase.get("/user", {headers: {Authorization: `Bearer ${token}`}});
}

export default GetUser;