import AxiosBase from "../axiosBase"; // Importando a configuração base do Axios

const Logout = (token) => {
    return AxiosBase.delete('/logout', {
        headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`  // Passando o token no cabeçalho da requisição
        }
    });
};

export default Logout;
